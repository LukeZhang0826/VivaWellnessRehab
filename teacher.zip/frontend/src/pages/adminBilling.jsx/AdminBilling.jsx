import React from 'react'

const AdminBilling = () => {
  return (
    <div>
      AdminBilling
    </div>
  )
}

export default AdminBilling
