import React from "react"
import ClientBooking from "../../components/clientBooking/ClientBooking"

const BookingPage = () => {
    return (
        <ClientBooking />
    )
}

export default BookingPage
