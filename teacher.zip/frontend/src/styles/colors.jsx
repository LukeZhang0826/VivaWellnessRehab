const colors = {
    "primary": "#6CC1C3",
    "secondary": "#ABC3CD",
    "light": "#DFE9EB",
    "dark": "#3B6E99",
    "grey": "#757575",
    "translucent-lightgrey": "#75757533",
    "translucent-grey": "#75757588",
}

export default colors;